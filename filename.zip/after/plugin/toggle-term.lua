require("toggleterm").setup{
shell = vim.o.shell,
terminal_mappings=true,
}

