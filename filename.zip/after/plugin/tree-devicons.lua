require('nvim-web-devicons').setup()
